import detecta

numero = int(input("Digite um numero natural: "))

if detecta.detecta(numero) == "multiploambos":
    print("fizzbuzz")
if detecta.detecta(numero) == "multiplocinco":
    print("fizz")
if detecta.detecta(numero) == "multiplosete":
    print("buzz")
if detecta.detecta(numero) == "nenhum":
    print("miss")

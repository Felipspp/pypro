def detecta(numero):
    if numero % 5 == 0 and numero % 7 == 0:
        return "multiploambos"
    elif numero % 5 == 0:
        return "multiplocinco"
    elif numero % 7 == 0:
        return "multiplosete"
    else:
        return "nenhum"